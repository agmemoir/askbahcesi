GreenSock-JS
============

Public repository for GreenSock's JavaScript libraries like GSAP. See http://www.greensock.com/gsap-js/ for details.

Getting started: http://www.greensock.com/get-started-js/

Full documentation: http://api.greensock.com/js/

jQuery plugin: http://www.greensock.com/jquery-gsap-plugin/

Copyright (c) 2014, GreenSock. All rights reserved. This work is subject to the terms in http://www.greensock.com/terms_of_use.html or for Club GreenSock members, the software agreement that was issued with the membership.